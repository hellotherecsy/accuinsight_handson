import requests
import os
import time

root_path = '.' #pred image path
image_list = os.listdir(root_path)


def get_model_result(image, image_path):
    headers = {'token': ''} #api token
    files = {'input': (image, open(image_path, 'rb')), }

    return requests.post('', headers=headers, files=files).text #api address

result_dic = dict()

for image in image_list:
    image_path = os.path.join(root_path, image)
    # print(image_path)

    result_dic[image] = get_model_result(image, image_path)
    time.sleep(0.5)
    # print(image, result_dic[image])

# print(result_dic)
label_dic = {0: 'forest', 1: 'buildings', 2: 'glacier', 3: 'street', 4: 'mountain', 5: 'sea'}

for img_name in sorted(result_dic.keys()):
    result_str = img_name + ': ' + label_dic[int(result_dic[img_name][1])]
    print(result_str)

